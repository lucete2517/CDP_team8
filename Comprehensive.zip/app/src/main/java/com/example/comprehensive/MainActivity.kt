package com.example.comprehensive

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.hongdroid.registerloginexample.R

class MainActivity : AppCompatActivity() {
    private val TAG = "MainActivity"
    private var tv_id: TextView? = null
    private var tv_pass: TextView? = null

    protected override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tv_id = findViewById(R.id.tv_id)
        tv_pass = findViewById(R.id.tv_pass)
        val intent: Intent = getIntent()
        val userID = intent.getStringExtra("userID")
        val userPass = intent.getStringExtra("userPass")
        tv_id!!.text = userID
        tv_pass!!.text = userPass
    }
}