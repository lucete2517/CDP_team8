var mysql = require('mysql');

var conn = mysql.createConnection({
    host : "localhost",
    user : "root",
    password : "456258",
    database : "test"
});

conn.connect();

conn.query("SELECT * FROM test", function(err, results){
    if(err){
        console.log(err);
    }
    console.log(results);
});

conn.end();