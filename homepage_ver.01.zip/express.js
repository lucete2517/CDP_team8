const express = require('express')
const test = express()
const port = 3000

test.get('/', (req, res) => res.send('Hello World!'))

test.listen(port, () => console.log('Connecting'))