package com.example.myapplication;

public class PersonalData {

    private String member_mid;

    public String getMember_mid(){
        return member_mid;
    }

    public void setMember_mid(String member_mid) {
        this.member_mid = member_mid;
    }
}
